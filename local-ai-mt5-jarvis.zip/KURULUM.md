# JARVIS — Windows'ta Kurulum

## 1) Komuta Merkezi (panel) — http://localhost:3000
1. Bu klasörde **`PANEL_KUR.bat`** dosyasına çift tıklayın (ilk sefer).
   - Node.js yoksa kurar. **PostgreSQL GEREKMEZ** — gömülü veritabanı (`data\jarvis.db.tgz`) kullanılır.
2. Tarayıcı açılır: **http://localhost:3000** → `demo@jarvis.local` / `jarvis123`
3. Sonraki açılışlarda sadece **`PANEL_BASLAT.bat`**.

> Harici PostgreSQL kullanmak isterseniz `.env.local` içine
> `DATABASE_URL=postgresql://kullanici:sifre@127.0.0.1:5432/jarvis` yazın ve `npx drizzle-kit push` çalıştırın.

## 2) Yerel Ajan (JARVIS.exe) — MT5 + ses + derleyici
1. Panelde **Yerel Ajan** → **⬇ JARVIS-Agent.zip** (Panel URL otomatik `http://localhost:3000` olur).
2. Zip'i çıkartın → **`KUR.bat`**.

## Veriler / yedek
Tüm panel verileri tek dosyadadır: `data\jarvis.db.tgz` (bir önceki oturum: `.bak`). Yedek için bu dosyayı kopyalayın.

## Güncelleme (baştan kurmak gerekmez)
- **Panel:** yeni dosyaları eski klasörün üzerine çıkartın. `data\` (veriler) ve `.env.local` projede olmadığı için silinmez.
  Sonra `PANEL_BASLAT.bat` — `VERSION` değiştiyse kendisi yeniden derler (npm paketlerini de günceller).
- **Ajan:** `CALISTIR.bat` ile açın; ajan her başlangıçta panelden yeni dosyaları indirir, `config.json`'a dokunmaz.
  EXE kullanıyorsanız güncelleme paketini çıkartıp `build_exe.bat --no-models` çalıştırın.
- Güncelleme paketi: panel → Yerel Ajan → "Güncelleme paketi (config.json içermez)".
